"use strict";

$(document).ready(function () {
  // banner
  $('.slider').slick({
    arrows: false,
    dots: true,
    infinite: true,
    speed: 500,
    fade: true,
    autoplay: true,
    autoplaySpeed: 5000,
    cssEase: 'linear'
  }); // .btn_reserv

  $('.btn_reserv').on('click', function () {
    $('html, body').animate({
      scrollTop: $("#in_reservation").offset().top - 40
    }, 800);
  }); // popup

  $('.btn_close').on('click', function () {
    $('.popup').stop().fadeOut();
  }); // 預約類型 切換

  $('.appointment_type a.btn').on('click', function () {
    var $index = $(this).index() - 1;
    $('.appointment_type a.btn,#in_reservation .content').removeClass('active');
    $('.appointment_type a.btn:eq(' + $index + '),#in_reservation .content:eq(' + $index + ')').addClass('active');
  }); // 日曆套件
  // https://fullcalendar.io/

  $('#calendar').fullCalendar({
    editable: true,
    header: {
      // title, prev, next, prevYear, nextYear, today
      left: '',
      center: 'prev,title,next',
      right: ''
    },
    viewRender: function viewRender(view) {
      var fecha = view.title.split(" ");
      var mes = fecha[0];
      var ano = fecha[1];
      $('.fc-header-title').html("<h2>".concat(mes, "</h2><span>").concat(ano, "</span>"));
    },
    // 諮詢預約日期點選
    dayClick: function dayClick(date) {
      var timeYear = date.getFullYear(); // 取得月份 前面補零 後面+1 

      var timeMonth = (date.getMonth() + 1 < 10 ? '0' : '') + (date.getMonth() + 1); // 取得日期

      var timeDate = date.getDate(); // 時間組合 西曆非國曆

      var calculating = "".concat(timeYear, " \u5E74 ").concat(timeMonth, " \u6708 ").concat(timeDate, " \u65E5");
      $('.use_data input').val(calculating);
    }
  }); // 日期按鈕

  $('.fc-button-prev,.fc-button-next').on('click', function () {
    calendar();
  }); // 標註諮詢預約 ＆ 預約額滿

  function calendar() {
    if ($('table').length > 0) {
      //諮詢預約
      var holiday = ['2020-11-07', '2020-11-08', '2020-11-11', '2020-11-23', '2020-12-10'];
      $.each(holiday, function (i, val) {
        var date = val;
        $(".fc-day[data-date=" + date + "]").addClass('holiday');
      }); //預約額滿

      var full = ['2020-11-09', '2020-11-14', '2020-11-15', '2020-11-17', '2020-11-26',, '2020-12-01'];
      $.each(full, function (i, val) {
        var date2 = val;
        $(".fc-day[data-date=" + date2 + "]").addClass('data_full');
      });
    }
  }

  calendar();
});